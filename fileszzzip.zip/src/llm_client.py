import os
import requests
from typing import Optional


class OllamaClient:

    def __init__(self):
        self.base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.chat_model = "qwen2.5-coder:1.5b"
        self.coder_model = "qwen2.5-coder:1.5b"
        self.api_url = f"{self.base_url}/api/generate"

    def is_code_request(self, question: str) -> bool:
        """Detect if the user is asking about code generation or explanation"""
        code_keywords = [
            "write", "code", "function", "generate", "create",
            "explain", "debug", "fix", "script", "program",
            "class", "loop", "algorithm", "implement", "error",
            "python", "java", "javascript", "sql", "html", "css",
            "اكتب", "كود", "برنامج", "دالة", "شرح", "اشرح"
        ]
        question_lower = question.lower()
        return any(keyword in question_lower for keyword in code_keywords)

    def generate_response(self, question: str, context: str) -> str:
        try:
            if not self.check_connection():
                return self._get_fallback_response()

            # Pick prompt style based on request type
            if self.is_code_request(question):
                model = self.coder_model
                prompt = self._create_code_prompt(question, context)
            else:
                model = self.chat_model
                prompt = self._create_rag_prompt(question, context)

            payload = {
                "model": model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "num_predict": 2000
                }
            }

            response = requests.post(
                self.api_url,
                json=payload,
                timeout=180
            )

            if response.status_code == 200:
                result = response.json()
                return result.get("response", "Sorry, I couldn't generate a response.")
            else:
                return f"Error: Ollama API returned status code {response.status_code}"

        except requests.exceptions.Timeout:
            return "⏱️ Request timed out. The model is taking too long — try a simpler question."
        except requests.exceptions.RequestException as e:
            return f"Error connecting to Ollama: {str(e)}. Please make sure Ollama is running with 'ollama serve'."
        except Exception as e:
            return f"Unexpected error: {str(e)}"

    def _create_rag_prompt(self, question: str, context: str) -> str:
        return f"""You are a helpful AI assistant that answers questions based on the provided context.
Use the following context to answer the user's question.
If the answer cannot be found in the context, say so clearly and don't make up information.

Context:
{context}

Question: {question}

Answer:"""

    def _create_code_prompt(self, question: str, context: str) -> str:
        context_section = f"""
Relevant context from uploaded documents (use if helpful):
{context}
""" if context.strip() else ""

        return f"""You are an expert programming assistant. Write clean, working code with comments.

Rules:
- Always wrap code inside a markdown code block with the language name, like ```python
- Add short comments explaining key lines
- After the code block, write a brief explanation of how it works

{context_section}
User request: {question}

Response:"""

    def _get_fallback_response(self) -> str:
        return """I'm sorry, but I can't connect to the local AI model (Ollama).

Please make sure:
1. Ollama is installed
2. Run 'ollama serve' in your terminal
3. Models are downloaded: 'ollama pull qwen2.5-coder:1.5b'"""

    def check_connection(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False

    def list_models(self) -> list:
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            if response.status_code == 200:
                data = response.json()
                return [model["name"] for model in data.get("models", [])]
            return []
        except:
            return []